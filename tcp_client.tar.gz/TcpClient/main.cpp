﻿#include <cstdio>
#include "TcpSocket.h"
#include <string.h>
#include <iostream>
#include <unistd.h>
using namespace std;

int main()
{
	// 创建套接字
	TcpSocket socket;
	// 连接服务器
	cout << "开始连接...";
	socket.connectToHost("127.0.0.1", 9898, 10000);
	cout << "连接成功...";

	// 通信
	while (1)
	{
		char* sendmsg = "hello server ...";
		cout << "发送数据" << sendmsg << endl;
		socket.sendMsg(sendmsg, strlen(sendmsg), 10000);
		// 接收数据
		int recvLen = -1;
		char* recvMsg = NULL;
		socket.recvMsg(&recvMsg, recvLen, 10000);
		printf("recvServer Msg: %s\n", recvMsg);
		socket.freeMemory(&recvMsg);
		sleep(1);
	}
    printf("hello from TcpClient!\n");
    return 0;
}