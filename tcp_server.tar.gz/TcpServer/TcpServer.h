﻿#pragma once
#include <netinet/in.h>
#include <arpa/inet.h>
#include "itcastlog.h"
#include "TcpSocket.h"

class TcpServer
{
public:
	TcpServer();
	~TcpServer();

	// 服务器设置监听
	int setListen(unsigned short port);
	// 等待并接受客户端连接请求, 默认连接超时时间为30s
	TcpSocket* acceptConn(int timeout = 30);

private:
	int acceptTimeout(int wait_seconds);

private:
	int m_lfd;	// 用于监听的文件描述符
	struct sockaddr_in m_addrCli;
	ItcastLog m_log;
};

