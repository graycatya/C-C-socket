﻿#include <cstdio>
#include "TcpServer.h"
#include <iostream>
#include <string.h>
using namespace std;

int main()
{
	// 创建对象
	TcpServer *server = new TcpServer;
	// 设置监听
	server->setListen(9898);
	// 等待并接受连接请求
	cout << "开始accept..." << endl;
	TcpSocket* sockTcp = server->acceptConn(1000);
	cout << "接受了一个客户端的连接请求..." << endl;
	while (1)
	{
		// 通信
		int recvLen = -1;
		char* recvBuf = NULL;
		sockTcp->recvMsg(&recvBuf, recvLen, 1000);
		cout << "recvBuf: " << recvBuf << endl;
		// 发送数据
		char* p = "hello, client ...";
		sockTcp->sendMsg(p, strlen(p), 1000);
		sockTcp->freeMemory(&recvBuf);
	}
    return 0;
}